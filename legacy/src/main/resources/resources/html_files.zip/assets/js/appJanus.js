var appJanus = angular.module("appJanus", []);

/*
* Direttiva per scaricare file
*/
appJanus.directive('exportToCsv',function(){
	return {
  	restrict: 'A',
  	link: function (scope, element, attrs) {
        var data = angular.fromJson(getResults());
  		  var el = element[0];
        element.bind('click', function(e){
        	var table = e.target.nextElementSibling;
        	var csvString = '';
          //Intestazione da tabella
		  csvString += "No.\tId\tSMILES\tP assessment [class]\tP assessment [index]\tP reliability\tP score";
		  csvString += "\tB assessment [log units]\tB reliability\tB score";
		  csvString += "\tT assessment [mg/l]\tT reliability\tT score";
		  csvString += "\tC assessment\tC reliability\tC score";
		  csvString += "\tM assessment\tM reliability\tM score";
		  csvString += "\tR assessment\tR reliability\tR score";
		  csvString += "\tED assessment [class]\tED assessment [index]\tED reliability\tED score";
		  csvString += "\tSCORE(vPvB)\tSCORE(SVHC)\tSCORE(PBT)";
          csvString += "\n";
          //Corpo csv dall'oggetto
          for(var j=0; j<data.length; j++)
          {
            csvString += data[j].num + "\t" + data[j].id + "\t" + data[j].smiles;
			csvString += "\t" + data[j].p_cla + "\t" + data[j].p_ass + "\t" + data[j].p_rel + "\t" + data[j].p_sco;
            csvString += "\t" + data[j].b_ass + "\t" + data[j].b_rel + "\t" + data[j].b_sco;
            csvString += "\t" + data[j].t_ass + "\t" + data[j].t_rel + "\t" + data[j].t_sco;
            csvString += "\t" + data[j].c_cla + "\t" + data[j].c_rel + "\t" + data[j].c_sco;
            csvString += "\t" + data[j].m_cla + "\t" + data[j].m_rel + "\t" + data[j].m_sco;
            csvString += "\t" + data[j].r_cla + "\t" + data[j].r_rel + "\t" + data[j].r_sco;
            csvString += "\t" + data[j].ed_cla + "\t" + data[j].ed_ass + "\t" + data[j].ed_rel + "\t" + data[j].ed_sco;
            csvString += "\t" + data[j].s_vpvb + "\t" + data[j].s_svhc + "\t" + data[j].s_pbt;
			csvString += "\n";
          }

					//Download file
					if ( window.navigator.msSaveOrOpenBlob && window.Blob )
					{
						var blob = new Blob( [ csvString ], { type: "text/csv" } );
						navigator.msSaveOrOpenBlob( blob, "janus-result.txt" );
					}
					else
					{
						var a = $('<a/>', {
								style:'display:none',
								href:'data:application/octet-stream;base64,'+ btoa(csvString),
								download:'janus-result.txt'
						}).appendTo('body');
						a[0].click();
						a.remove();
					}
      });
  	}
	}
});

appJanus.filter('sommaValori', function () {
    return function (data, key) {
        if (angular.isUndefined(data) && angular.isUndefined(key))
            return 0;
        var sum = 0;

        angular.forEach(data,function(v,k){
      		if (v[key]!=null)
          	sum = sum + parseFloat(v[key]);
        });
        return sum;
    }
});


appJanus.controller('Results', function($scope) {

    $scope.rundate = getDate();

    $scope.truncate_string = function(str, length) {
        ending = ' [..]';
        if (str.length > length) {
          return str.substring(0, length - ending.length) + ending;
        } else {
          return str;
        }
    }

	
    $scope.scoreClassP = function(score) {
		if (score == -999999) return 'cl-gray';
        if (score <1) return 'cl-green';
        if (score <2) return 'cl-orange';
        return 'cl-red';
    }

    $scope.scoreClassB = function(score) {
		if (score == -999999) return 'cl-gray';
        if (score < 3) return 'cl-green';
        if (score < 3.7) return 'cl-orange';
        return 'cl-red';
    }

    $scope.scoreClassT = function(score) {
		if (score == -999999) return 'cl-gray';
        if (score < 0.01) return 'cl-red';
        if (score < 1) return 'cl-orange';
        return 'cl-green';
    }

    $scope.scoreClassCMR = function(score) {
		if (score == -999999) return 'cl-gray';
        if (score < 0.5) return 'cl-green';
        if (score > 0.5) return 'cl-red';
        return 'cl-gray';
    }


	
	$scope.labelCarc = function(score, val) {
		if (score == -999999) return '-';
		if (score == 0.5) return '-';
		if (score > 0.5) return val;
		return 'NC';
	}
	
	$scope.labelMuta = function(val) {
		if (val == -999999) return '-';
		if (val == 0.5) return '-';
		if (val > 0.5) return 'M';
		return 'NM';
	}
	
	$scope.labelDevtox = function(val) {
		if (val == -999999) return '-';
		if (val == 0.5) return '-';
		if (val > 0.5) return 'T';
		return 'NT';
	}
	
	$scope.labelED = function(val) {
		if (val == -999999) return '-';
		if (val > 0.5) return 'A';
		return 'NA';
	}
	
	$scope.filterMV = function(val) {
		if (val == -999999) return '-';
		return val;
	}
	
    $scope.orderByField = 'num';
    $scope.reverseSort = false;
	$scope.checkedPBT = false;
	$scope.checkedCMR = false;
	$scope.checkedED = false;
	$scope.checkedSCO = false;
	$scope.checkedSCOFIN = true;
    $scope.res = angular.fromJson(getResults());
});


appJanus.controller('Details', function($scope, $filter) {

    $scope.res = angular.fromJson(getResults());

    $scope.curNum = window.location.search.split('n=')[1];

    $scope.result = $filter('filter')($scope.res, {num: Number($scope.curNum)}, true)[0];

	if ($scope.result.metabolites.length != 0)
		$scope.metabolites = ($scope.result.metabolites).split(',');
	else
		$scope.metabolites = null;
	
    $scope.scoreClassP = function(score) {
		if (score == -999999) return 'font-icon-detail summary__gray';	
        if (score <1) return 'font-icon-detail summary__ok';
        if (score <2) return 'font-icon-detail summary__n';
        return 'font-icon-detail summary__ko';
    }

    $scope.scoreClassB = function(score) {
		if (score == -999999) return 'font-icon-detail summary__gray';	
        if (score < 3) return 'font-icon-detail summary__ok';
        if (score < 3.7) return 'font-icon-detail summary__n';
        return 'font-icon-detail summary__ko';
    }

    $scope.scoreClassT = function(score) {
		if (score == -999999) return 'font-icon-detail summary__gray';	
        if (score < 0.01) return 'font-icon-detail summary__ko';
        if (score < 1) return 'font-icon-detail summary__n';
        return 'font-icon-detail summary__ok';
	}
	
    $scope.scoreClassCMR = function(score) {
		if (score == -999999) return 'font-icon-detail summary__gray';	
        if (score < 0.5) return 'font-icon-detail summary__ok';
        if (score > 0.5) return 'font-icon-detail summary__ko';
        return 'font-icon-detail summary__gray';
    }
	
	$scope.filterMV = function(val) {
		if (val == -999999) return '-';
		return val;
	}

	
});
